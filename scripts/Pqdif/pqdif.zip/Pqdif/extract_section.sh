#!/bin/bash
sed -n '270,500p' /home/liweiw/Pqdif/Program.cs
